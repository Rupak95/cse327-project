<?php

$link=mysqli_connect("localhost", "root","usbw");
mysqli_select_db($link,"hajj");

?>
<!DOCTYPE html>
<html>
<head>
	<title>ADMIN</title>
</head>
<body>

</body>
</html>