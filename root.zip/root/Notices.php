<!DOCTYPE html>
<html>
<head>
	<title>Notices</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body style="background-color:#071019;">

	<header>
    
    <div class="logo">.
        <img src="Images/logo.jpg">
      </div>
    <div class="name">
        <img src="Images/name.png">
      </div>
      <form method="POST" action="Search_hajji.php" id="search">
        <input name="search_h" type="text" size="40" placeholder="Search..." />
      </form>
      
      <div class="row">
      <ul class="main-nav">
        <li><a href="index.php"> Home </a></li>
        <li><a href="News & Info.php"> News & Info </a></li>
        <li><a href="Hajj_Agency.php"> Hajj Agency </a></li>
        <li><a href="Notices.php"> Notices </a></li>
        <li><a href="Guide.php"> Guide </a></li>
        <li><a href="Contact.php"> Contact </a></li>
      </ul>
    </div>

  </header>
  <hr>

  <div class="Notice">
     <p> <font color="00FF00"> ****  The Flight of Bangladesh Airlines on 20-07-17 has been cancled.</font>
     </p>
     <br>
   <p><font color="00FF00">  ****  If You Want to know anything About your Guide please click the link </font><a href= Guide.php><font color="FF0000">Guide Info</font></a></p>
   <br>

   <p><font color="00FF00"> ****  Who have applied for visa and not yet collected  the documents, are requested to collect  them  as soon as possible from the Hajj Control office during working hours(10:00 AM to 4:00 PM, Sunday through Thursday). </font> </p>
   <br>
     <p><font color="00FF00">****  Be Aware of</font><font color = "#FF0040"><b>&nbsp&nbsp"Fake Agencies"</b></font></p>
    
   <br>
    <p><font color="00FF00">****  To Check The Name of Registered Agencies Click The Link </font>&nbsp&nbsp&nbsp&nbsp<a href= Hajj_Agency.php><font color="FF0000">Hajj Agency</font></a></p>
  </div>
  
  

<footer class="footer">
  <p><font size="4px">About US</font></p>
  <p><font size="3px">Managed by Web-Dream Ltd on behalf of Ministry Of Religious Affairs.   
Help Desk Phone Number: 01817-098032,  Email: nhassan213@gmail.com</font></p>
</footer>







</body>
</html>